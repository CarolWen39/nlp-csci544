import sys
import os
import argparse


parser = argparse.ArgumentParser(prog="eval", description="Evaluation of HW3")
parser.add_argument("-g", "--gold", help="gold standard file")
parser.add_argument("-p", "--pred", help="prediction file")
args = parser.parse_args()

pred = args.pred
gold = args.gold


total = 0
corr = 0
with open(gold, 'r') as gf, open(pred, 'r') as pf:
    for gline in gf:
        gline = gline.strip()
        if len(gline) == 0:
                pline = pf.readline()
                continue

        tokens = gline.split()
        # print tokens
        gidx = tokens[0]
        gword = tokens[1]
        glabel = tokens[2]

        pline = pf.readline()
        pline = pline.strip()

        tokens = pline.split()
        pidx = tokens[0]
        pword = tokens[1]
        plabel = tokens[2]

        if gidx != pidx:
            print('warning: index mismatch: {}, {}'.format(gidx, pidx))

        if gword != pword:
            print('warning: word mismatch: {}, {}'.format(gword, pword))

        total += 1
        if glabel == plabel:
            corr += 1

print("total: {}, correct: {}, accuracy: {:.2f}%".format(total, corr, float(corr) * 100 / total))
